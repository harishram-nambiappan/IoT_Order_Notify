import cv2
import threading
from firebase import firebase
from datetime import date
from datetime import datetime


def firebase_check():
    app_info = firebase.FirebaseApplication('https://iot-order-notify.firebaseio.com', None)
    order_list = app_info.get('/Orders/har', None)
    time_list = []
    for i in order_list:
        if order_list[i].get('order_status') == 'Yet to receive':
            tod_date = date.today()
            today_date = tod_date.strftime("%d-%m-%Y")          
            if order_list[i].get('order_date') == today_date:
               tod_time = datetime.today()
               now_time = tod_time.strftime('%H:%M')
               time_list.append([i, int(order_list[i].get('recv_time').split(':')[0])-
                                 int(now_time.split(':')[0])])
    if len(time_list) > 0:
        min_time = time_list[0][1]
        min_id = time_list[0][0]                         
        for i in range(1, len(time_list)):
            if min_time > time_list[i][1]:
                min_time = time_list[i][1]
                min_id = time_list[i][0]
        order_list[min_id]['order_status'] = 'Received'
        notify = app_info.put('/Orders/har/', min_id, order_list[min_id])
         

cam = cv2.VideoCapture(0)
obj_det = cv2.CascadeClassifier("Training_Data/Cardboard_Box/classifier/cascade.xml")
flag = 0
while True:
   ret, frame = cam.read()
   cv2.imshow("frame", frame)
   frame_gr = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
   frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
   obj_fnd = obj_det.detectMultiScale(frame_gr)
   no_obj_fnd = len(obj_fnd)
   if no_obj_fnd > 1:
       if flag == 0:
           flag = 1
           print("Object found")
           order_check = threading.Thread(target=firebase_check)
           order_check.start()
   else:
       flag = 0
   key = cv2.waitKey(20)
   if key == 27:
      break