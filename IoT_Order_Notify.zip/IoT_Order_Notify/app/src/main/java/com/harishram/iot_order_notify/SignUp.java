package com.harishram.iot_order_notify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;

import java.net.*;
import java.io.*;

@IgnoreExtraProperties
class User_Details{
    public String name,email,username,pwd;
    public User_Details(){

    }
    public User_Details(String name, String email, String username, String pwd){
        this.name = name;
        this.email = email;
        this.username = username;
        this.pwd = pwd;
    }
}

public class SignUp extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        TextView sign_up = (TextView)findViewById(R.id.textView13);
        TextView back = (TextView)findViewById(R.id.textView15);
        final EditText name_fi = (EditText)findViewById(R.id.editText3);
        final EditText email_fi = (EditText)findViewById(R.id.editText4);
        final EditText username_fi = (EditText)findViewById(R.id.editText5);
        final EditText pwd_fi = (EditText)findViewById(R.id.editText6);
        final EditText re_pwd_fi = (EditText)findViewById(R.id.editText7);

        final DatabaseReference dbref = FirebaseDatabase.getInstance().getReference();
        System.out.println(dbref);

        sign_up.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(pwd_fi.getText().toString().equals(re_pwd_fi.getText().toString())){
                    final String name = name_fi.getText().toString();
                    final String email = email_fi.getText().toString();
                    final String username = username_fi.getText().toString();
                    final String pwd = pwd_fi.getText().toString();
                    final String sign_up_request = "SignUp/"+username+","+pwd+","+name+","+email;
                    new Thread(new Runnable(){
                        @Override
                        public void run(){
                            try {
                                /*InetAddress server_addr = InetAddress.getByName("DESKTOP-A66UJUK");
                                System.out.println(server_addr.getHostAddress());*/
                                /*Socket sign_up_socket = new Socket("10.219.164.181", 2000);
                                OutputStream sign_up_os = sign_up_socket.getOutputStream();
                                sign_up_os.write(sign_up_request.getBytes());*/
                        /*InputStream sign_up_is = sign_up_socket.getInputStream();
                        BufferedReader sign_up_br = new BufferedReader(new InputStreamReader(sign_up_is));
                        String sign_up_response = sign_up_br.readLine();
                        System.out.println(sign_up_response);*/
                                //sign_up_socket.close();
                                User_Details user_info = new User_Details(name, email, username, pwd);
                                dbref.child("Users").child(username).setValue(user_info);
                            }
                            catch(Exception e){
                                e.printStackTrace();
                            }
                        }
                    }).start();
                    Intent login_int = new Intent(SignUp.this, Login.class);
                    startActivity(login_int);
                }
                else{
                    Context ctt = getApplicationContext();
                    String info = "Passwords not matching";
                    Toast noti = Toast.makeText(ctt, info, Toast.LENGTH_SHORT);
                    noti.show();
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent login_int = new Intent(SignUp.this, Login.class);
                startActivity(login_int);
            }
        });
    }
}
