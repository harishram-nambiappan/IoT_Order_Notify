package com.harishram.iot_order_notify;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static com.harishram.iot_order_notify.OrderNotification.order_channel_id;

public class NotificationService extends Service {
    private NotificationManagerCompat orderManager;
    DatabaseReference dbref;
    String username,order_no,order_date;
    int state_flag = 0;
    @Override
    public void onCreate(){
        super.onCreate();
        orderManager = NotificationManagerCompat.from(this);
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId){
        username = intent.getStringExtra("username");
        order_no = intent.getStringExtra("order_no");
        order_date = intent.getStringExtra("order_date");
        //  while(state_flag == 0){
            dbref = FirebaseDatabase.getInstance().getReference("Orders/"+username+"/"+order_no);
            dbref.orderByKey().addChildEventListener(new ChildEventListener(){

                @Override
                public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                    String status = snapshot.getValue(String.class);
                    if(status.equals("Received")){
                        //if(!notified.equals("True")) {
                            Notification order_not = new NotificationCompat.Builder(getBaseContext(), order_channel_id)
                                    .setSmallIcon(R.drawable.order_alert)
                                    .setContentTitle("IoT-Order-Notify")
                                    .setContentText("Your order " + order_no + " scheduled on "+ order_date + " has arrived")
                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                    .build();
                            orderManager.notify(1, order_not);
                            //dbref.child("Orders").child(username).child(order_no).child("notified").setValue("True");
                            state_flag = 1;
                        //}
                    }
                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        //}
        return Service.START_REDELIVER_INTENT;
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
    }
}
