package com.harishram.iot_order_notify;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

class Order_Details{
    public String order_no;
    public String recv_time;
    public String order_date;
    public String order_status;
    public Order_Details(){

    }
    public Order_Details(String order_no,String recv_time,String order_date){
        this.order_no = order_no;
        this.recv_time = recv_time;
        this.order_date = order_date;
        this.order_status = "Yet to receive";
    }
}

public class EnterNewOrder extends AppCompatActivity {

    DatabaseReference dbref;
    String order_date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_new_order);
        final String log_username = getIntent().getStringExtra("username");
        final EditText order_no_fi = (EditText)findViewById(R.id.editText9);
        final EditText recv_time_fi = (EditText)findViewById(R.id.editText10);
        final CalendarView recv_date_inf = (CalendarView)findViewById(R.id.calendarView2);
        SimpleDateFormat date_format = new SimpleDateFormat("dd-MM-yyyy");
        order_date = date_format.format(new Date(recv_date_inf.getDate()));
        TextView submit = (TextView)findViewById(R.id.textView17);
        TextView back = (TextView)findViewById(R.id.textView16);
        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String order_no = order_no_fi.getText().toString();
                String recv_time = recv_time_fi.getText().toString();
                System.out.println(order_date);
                Order_Details order_info = new Order_Details(order_no,recv_time,order_date);
                dbref = FirebaseDatabase.getInstance().getReference();
                dbref.child("Orders").child(log_username).child(order_no).setValue(order_info);
                Intent notify_in = new Intent(getBaseContext(), NotificationService.class);
                notify_in.putExtra("username",log_username);
                notify_in.putExtra("order_no",order_no);
                notify_in.putExtra("order_date",order_date);
                startService(notify_in);
                Intent in = new Intent(EnterNewOrder.this, MainActivity.class);
                in.putExtra("username",log_username);
                startActivity(in);
            }
        });
        back.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View v){
               Intent in = new Intent(EnterNewOrder.this,MainActivity.class);
               in.putExtra("username",log_username);
               startActivity(in);
           }
        });
    }
}
