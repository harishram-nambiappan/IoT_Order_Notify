package com.harishram.iot_order_notify;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final String log_username = getIntent().getStringExtra("username");
        TextView logout = (TextView)findViewById(R.id.textView10);
        TextView enter_new_order = (TextView)findViewById(R.id.textView2);
        TextView view_order = (TextView)findViewById(R.id.textView3);
        logout.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent login_act = new Intent(MainActivity.this, Login.class);
                startActivity(login_act);
            }
        });
        enter_new_order.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent new_order_int = new Intent(MainActivity.this, EnterNewOrder.class);
                new_order_int.putExtra("username",log_username);
                startActivity(new_order_int);
            }
        });
        view_order.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent view_order_int = new Intent(MainActivity.this, ViewOrder.class);
                view_order_int.putExtra("username", log_username);
                startActivity(view_order_int);
            }
        });
    }
}
