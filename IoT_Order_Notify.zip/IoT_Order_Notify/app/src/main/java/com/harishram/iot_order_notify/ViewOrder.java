package com.harishram.iot_order_notify;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ViewOrder extends AppCompatActivity {

    TextView order_list;
    String log_username;
    DatabaseReference dbref;
    String order_info_list = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_order);
        log_username = getIntent().getStringExtra("username");
        order_list = (TextView)findViewById(R.id.textView12);
        dbref = FirebaseDatabase.getInstance().getReference("Orders/"+log_username);
        dbref.orderByKey().addChildEventListener(new ChildEventListener(){

            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Order_Details order_info = snapshot.getValue(Order_Details.class);
                order_info_list += "Order number: "+order_info.order_no+"\n";
                order_info_list += "Order Date: "+order_info.order_date+"\n";
                order_info_list += "Order Time: "+order_info.recv_time+"\n";
                order_info_list += "Order Status: "+order_info.order_status+"\n";
                order_info_list += "\n";
                order_list.setText(order_info_list);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    @Override
    public void onBackPressed(){
        log_username = getIntent().getStringExtra("username");
        Intent main_act_int = new Intent(ViewOrder.this, MainActivity.class);
        main_act_int.putExtra("username",log_username);
        startActivity(main_act_int);
    }
}
