package com.harishram.iot_order_notify;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;


public class OrderNotification extends Application {

    public static final String order_channel_id = "iot_notify";
    @Override
    public void onCreate(){
        super.onCreate();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel order_channel = new NotificationChannel(order_channel_id,"IoT-Order-Notify",
                    NotificationManager.IMPORTANCE_HIGH);
            order_channel.setDescription("Channel for Order Notification");

            NotificationManager order_manager = getSystemService(NotificationManager.class);
            order_manager.createNotificationChannel(order_channel);
        }

    }



}
