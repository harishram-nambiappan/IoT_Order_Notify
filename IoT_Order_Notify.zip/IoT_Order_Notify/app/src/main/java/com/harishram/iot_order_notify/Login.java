package com.harishram.iot_order_notify;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.net.InetAddress;

public class Login extends AppCompatActivity {

    String username;
    String pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        TextView login = (TextView)findViewById(R.id.textView8);
        TextView signup = (TextView)findViewById(R.id.textView7);
        final EditText username_fi = (EditText)findViewById(R.id.editText);
        final EditText pwd_fi = (EditText)findViewById(R.id.editText2);
        /*try {
            System.out.println(InetAddress.getLocalHost());
        }
        catch(Exception e){
            e.printStackTrace();
        }*/
        final DatabaseReference dbref = FirebaseDatabase.getInstance().getReference();
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                username = username_fi.getText().toString();
                pwd = pwd_fi.getText().toString();
                String login_request = "Login/"+username+","+pwd;
                DatabaseReference user_ref = FirebaseDatabase.getInstance().getReference("Users");
                user_ref.orderByChild(username).addChildEventListener(new ChildEventListener(){

                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                        User_Details db_user = snapshot.getValue(User_Details.class);
                        if((db_user.username.equals(username))&&(db_user.pwd.equals(pwd))){
                            Intent main_act_int = new Intent(Login.this, MainActivity.class);
                            main_act_int.putExtra("username",username);
                            startActivity(main_act_int);
                        }
                        else{
                            Toast invalid_info = Toast.makeText(getApplicationContext(),"Invalid Username or Password. Try Again",Toast.LENGTH_SHORT);
                            invalid_info.show();
                        }
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });

        signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent signup_int = new Intent(Login.this, SignUp.class);
                startActivity(signup_int);
            }
        });
    }
}
